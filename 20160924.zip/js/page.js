﻿// JavaScript Document





/**
* @name		:mainInit
* @author	:Nice
* @dependent:总初始化
*/
function mainInit(){
	
}
mainInit();
/* @end **/



/**
* @name		:名称
* @author	:作者
* @dependent:描述
*/

/* @end **/

/**
* @name		:
* @author	:Nice
* @version	:
* @type		:基类
* @explain	:
* @relating	:
* @dependent:
*/

/* @end **/